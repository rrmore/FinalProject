package com.example.futzm.finalproject;

/**
 * Created by futzm on 12/8/2017.
 */

public class Location {
}
